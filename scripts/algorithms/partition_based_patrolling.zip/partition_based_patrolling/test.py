#!/usr/bin/env python3

import rospy

rospy.set_param('/init_locations',5)
rospy.set_param('/use_sim_time',True)
rospy.set_param('/gui',False)


